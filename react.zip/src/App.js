import './index.css';
import About from './RawPages/About';
import Service from './RawPages/Service';
import Contact from './RawPages/Contact';
import Home from './RawPages/Home';
import Pages from './RawPages/Pages';
import { Route, Routes} from "react-router-dom";


function App() {
  return (
    <>
    
  <Routes>
    <Route path="/" element={<Home/>}/>
    <Route path="/About" element={<About/>}/>
    <Route path="/Service" element={<Service/>}/>
    <Route path="/Pages" element={<Pages/>}/>
    <Route path="/Contact" element={<Contact/>}/>
    </Routes>
    </>
  );
}
export default App;
