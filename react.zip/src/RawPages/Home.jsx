import React from 'react';
import Navbar from "../Components/Navbar";
import BootsrapCarousl from "../Components/BootsrapCarousl";
import Footer from "../Components/Footer";
import ProjectAbout from "../Components/ProjectAbout";
import ProjectServices from "../Components/ProjectServices";
import ProjectPages from "../Components/ProjectPages";



const Home = () => {
  return (
    <div>

      <Navbar/>
      <BootsrapCarousl/>
      <ProjectAbout/>
      <ProjectServices/>
      <ProjectPages/>
      <Footer/>
      
    </div>
  );
};

export default Home;
