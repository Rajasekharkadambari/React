import React from 'react'
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";
import BootsrapCarousl from "../Components/BootsrapCarousl";

import ProjectServices from "../Components/ProjectServices";

const Service = () => {
  return (
    <div>
      <Navbar/>
      <BootsrapCarousl/>
   
      <ProjectServices/>
      <Footer/>
    </div>
  );
};

export default Service;
