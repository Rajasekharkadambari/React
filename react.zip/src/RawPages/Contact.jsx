import React from 'react'
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";
import BootsrapCarousl from "../Components/BootsrapCarousl";
import ProjectContact from "../Components/ProjectContact";

const Contact = () => {
  return (
    <div>
       <Navbar/>
      <BootsrapCarousl/>
      <ProjectContact/>
      <Footer/>
    </div>
  )
}

export default Contact
