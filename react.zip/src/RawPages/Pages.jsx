import React from 'react'
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";
import BootsrapCarousl from "../Components/BootsrapCarousl";

import ProjectPages from "../Components/ProjectPages";

const Pages = () => {
  return (
    <div>
      <Navbar/>
      <BootsrapCarousl/>
      
      <ProjectPages/>
      <Footer/>
    </div>
  );
};

export default Pages;
