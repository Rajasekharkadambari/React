import React from 'react';
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";
import BootsrapCarousl from "../Components/BootsrapCarousl";
import ProjectAbout from "../Components/ProjectAbout";

const About = () => {
  return (
    <div>
      <Navbar/>
      <BootsrapCarousl/>
      <ProjectAbout/>
      <Footer/>
     
    </div>
  );
};

export default About;
