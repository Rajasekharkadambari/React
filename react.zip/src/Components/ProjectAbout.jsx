import "./ProjectAbout.css";
import React from 'react';
import Logo from '../img/about.jpg';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { FaStar } from "react-icons/fa";

const pageAboutus = () => {
  return (
  
    <Container fluid>
      <Row className="Rows">
        <Col className="imageSides" md={5}>
        <img src={Logo}/></Col>
        <Col className="imageSides-1" md={7}> 
       <h6 >ABOUT US</h6>
       <div className="sekharraj">
       <h1>We Offers Quality CCTV Systems & Services</h1>
       <h6>Diam dolor diam ipsum sit. Clita erat ipsum et lorem stet no lorem sit clita duo justo magna dolore</h6>
       <p>Tempor erat elitr rebum at clita. Diam dolor diam ipsum et tempor sit. Aliqu diam amet diam et eos labore. Clita erat ipsum et lorem et sit, sed stet no labore lorem sit. Sanctus clita duo justo et tempor eirmod magna dolore erat amet et magna</p>
       </div>
       <Row>
        <Col md={6}>
        <div className="skholla">
        <FaStar style={{color:"yellow",marginRight:"5px"}}/>
       <h5> 15 Years Experience</h5>

          </div>
        </Col>
        <Col md={6}>
        <div className="skholla-1">
        <FaStar style={{color:"yellow",marginRight:"5px" }}/>
        <h5>Award Winning</h5>
          </div>
        </Col>
       </Row>
        </Col>
        
      </Row>
    </Container>
   
  );
}
export default pageAboutus;