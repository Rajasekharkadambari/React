import React from 'react';
import './ProjectService.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { BiCctv,BiRightArrowAlt,BiCameraMovie } from "react-icons/bi";

 
const ProjectServices = () => {
  return (
    <div>
      <Container>
      <Row>
      <div className='swarna'>
      <p>SERVICES</p>
      <h1>Our Excellent CCTV <br/>Security Services</h1>
      </div>
      <Col>
      <div className='sarkar'>
      <BiCctv className='camera-1'/>
      <div className='swarnatara-1'>
      <h6>CCTV</h6>
      <h4>Installation</h4>
      <p>Kasd dolor no lorem sit tempor at justo rebum rebum stet justo elitr dolor amet sit</p>
     
      </div>
      <div className='rightarrow'>
      <a href='#'>Read More<BiRightArrowAlt/></a>
      </div>
      </div>
      
      
      </Col>


      <Col>
      <div className='sarkar'>
      <BiCctv className='camera-1'/>
      <div className='swarnatara-1'>
      <h6>CCTV</h6>
      <h4>Configuration</h4>
      <p>Kasd dolor no lorem sit tempor at justo rebum rebum stet justo elitr dolor amet sit</p>
     
      </div>
      <div className='rightarrow'>
      <a href='#'>Read More<BiRightArrowAlt/></a>
      </div>
      </div>
      </Col>

      <Col>
      <div className='sarkar'>
      <BiCameraMovie className='camera-1'/>
      <div className='swarnatara-1'>
      <h6>CCTV</h6>
      <h4>Maintenance</h4>
      <p>Kasd dolor no lorem sit tempor at justo rebum rebum stet justo elitr dolor amet sit</p>
     
      </div>
      <div className='rightarrow'>
      <a href='#'>Read More<BiRightArrowAlt/></a>
      </div>
      </div>
      </Col>
      </Row>
      <Row>
      <Col>
      <div className='sarkar'>
      <BiCctv className='camera-1'/>
      <div className='swarnatara-1'>
      <h6>CCTV</h6>
      <h4>Installation</h4>
      <p>Kasd dolor no lorem sit tempor at justo rebum rebum stet justo elitr dolor amet sit</p>
     
      </div>
      <div className='rightarrow'>
      <a href='#'>Read More<BiRightArrowAlt/></a>
      </div>
      </div>
      
      
      </Col>


      <Col>
      <div className='sarkar'>
      <BiCctv className='camera-1'/>
      <div className='swarnatara-1'>
      <h6>CCTV</h6>
      <h4>Configuration</h4>
      <p>Kasd dolor no lorem sit tempor at justo rebum rebum stet justo elitr dolor amet sit</p>
     
      </div>
      <div className='rightarrow'>
      <a href='#'>Read More<BiRightArrowAlt/></a>
      </div>
      </div>
      </Col>

      <Col>
      <div className='sarkar'>
      <BiCameraMovie className='camera-1'/>
      <div className='swarnatara-1'>
      <h6>CCTV</h6>
      <h4>Maintenance</h4>
      <p>Kasd dolor no lorem sit tempor at justo rebum rebum stet justo elitr dolor amet sit</p>
     
      </div>
      <div className='rightarrow'>
      <a href='#'>Read More<BiRightArrowAlt/></a>
      </div>
      </div>
      </Col>
      </Row>
      </Container>
    </div>
    
  )
}

export default ProjectServices;