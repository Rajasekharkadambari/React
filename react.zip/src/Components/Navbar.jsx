
import "./NavbarStyles.css";
import {Link} from "react-router-dom";
import { FaPhoneAlt } from "react-icons/fa";

const Navbar = () => {
 
  
    return (
        
    <div className="header">
        <Link to="/">
            <span className="safe">Safe</span>
            <span className="cam">Cam</span>
        </Link>
        <ul className="nav-menu">
        <li>
                <Link to="/">Home</Link>
            </li>
            <li>
                <Link to="/About">About</Link>
            </li>
            <li>
                <Link to="/Service">Service</Link>
            </li>
            
            <li>
                <Link to="/Pages">Pages</Link>
            </li>
            <li>
                <Link to="/Contact">Contact</Link>
            </li>
        </ul>
        <div className="phoneNumber">
        <p><FaPhoneAlt/>+123 456 789</p>
        </div>
        </div>
    
  
  );
};

export default Navbar;
