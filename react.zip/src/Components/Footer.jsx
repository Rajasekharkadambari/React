import React from 'react'
import './FooterStyle.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import {BsFillUmbrellaFill } from "react-icons/bs";
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';

function AutoLayoutExample() {
  return (
    <Container fluid rapidex>
      <Row className="saadhika">
        <Col md="3">
          <h4>Saadhika Kadambari</h4>
          <div className='social-links'>
          <p><BsFillUmbrellaFill size={"20px"} style={{color:"yellow",marginRight:"1rem"}}/><a href='#!' className='links'>Srinivas Krishna</a></p>
          <p><BsFillUmbrellaFill size={"20px"} style={{color:"yellow",marginRight:"1rem"}}/><a href='#!' className='links'>Srinivas Krishna</a></p>
          <p><BsFillUmbrellaFill size={"20px"} style={{color:"yellow",marginRight:"1rem"}}/><a href='#!' className='links'>Srinivas Krishna</a></p>
         <p> <BsFillUmbrellaFill size={"20px"} style={{color:"yellow",marginRight:"1rem"}}/><a href='#!' className='links'>Srinivas Krishna</a></p>
            </div>
        </Col>
        <Col md="3"><h4>Saadhika Kadambari</h4>
          <div className='social-links'>
          <p><BsFillUmbrellaFill size={"20px"} style={{color:"yellow",marginRight:"1rem"}}/><a href='#!' className='links'>Srinivas Krishna</a></p>
          <p><BsFillUmbrellaFill size={"20px"} style={{color:"yellow",marginRight:"1rem"}}/><a href='#!' className='links'>Srinivas Krishna</a></p>
          <p><BsFillUmbrellaFill size={"20px"} style={{color:"yellow",marginRight:"1rem"}}/><a href='#!' className='links'>Srinivas Krishna</a></p>
         <p> <BsFillUmbrellaFill size={"20px"} style={{color:"yellow",marginRight:"1rem"}}/><a href='#!' className='links'>Srinivas Krishna</a></p>

            </div></Col>
        <Col md="3">
        <h4>Saadhika Kadambari</h4>
          <div className='social-links'>
          <p><BsFillUmbrellaFill size={"20px"} style={{color:"yellow",marginRight:"1rem"}}/><a href='#!' className='links'>Srinivas Krishna</a></p>
          <p><BsFillUmbrellaFill size={"20px"} style={{color:"yellow",marginRight:"1rem"}}/><a href='#!' className='links'>Srinivas Krishna</a></p>
          <p><BsFillUmbrellaFill size={"20px"} style={{color:"yellow",marginRight:"1rem"}}/><a href='#!' className='links'>Srinivas Krishna</a></p>
         <p> <BsFillUmbrellaFill size={"20px"} style={{color:"yellow",marginRight:"1rem"}}/><a href='#!' className='links'>Srinivas Krishna</a></p>
            </div>
        </Col>
        <Col md="3">
        <h4>Saadhika Kadambari</h4>
          <div className='social-links'>
          <p><BsFillUmbrellaFill size={"20px"} style={{color:"yellow",marginRight:"1rem"}}/><a href='#!' className='links'>Srinivas Krishna</a></p>
          <p><BsFillUmbrellaFill size={"20px"} style={{color:"yellow",marginRight:"1rem"}}/><a href='#!' className='links'>Srinivas Krishna</a></p>
          <p><BsFillUmbrellaFill size={"20px"} style={{color:"yellow",marginRight:"1rem"}}/><a href='#!' className='links'>Srinivas Krishna</a></p>
         <p> <BsFillUmbrellaFill size={"20px"} style={{color:"yellow",marginRight:"1rem"}}/><a href='#!' className='links'>Srinivas Krishna</a></p>
            </div>
        </Col>
        <InputGroup className="mt-3 mx-auto prasad">
        <Form.Control
          placeholder="Your Mail"
          aria-label="Recipient's username"
          aria-describedby="basic-addon2"
        />
        <InputGroup.Text id="basic-addon2">Sign Up</InputGroup.Text>
      </InputGroup>
      </Row>

     
         </Container>
  );
}

export default AutoLayoutExample;