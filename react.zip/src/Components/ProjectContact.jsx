import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import './ProjectContact.css';
import FloatingLabel from 'react-bootstrap/FloatingLabel';
import { FaMapMarkerAlt } from "react-icons/fa";
import { HiOutlineMailOpen } from "react-icons/hi";
import { BsFillPhoneVibrateFill } from "react-icons/bs";

function BasicExample() {
  return (
  

    <Container>
    <Row>
    <div className='swarna-1'>
    <p>CONTACT US</p>
    <h1>Please Feel Free To <br/>Contact Us</h1>
</div>
    <Col md={6}>
    <Form>    
    <div className='fomvalidation'>
    <Row>
    <Col md={6}>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Email address</Form.Label>
        <Form.Control type="email" placeholder="Enter email" />
      </Form.Group></Col>
      <Col md={6}>
      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" placeholder="Password" />
      </Form.Group></Col></Row>
        <Row>
        <Col>
        <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" placeholder="Password" />
      </Form.Group>
      <FloatingLabel controlId="floatingTextarea2" label="Comments">
        <Form.Control
          as="textarea"
          placeholder="Leave a comment here"
          style={{ height: '100px' }}
        />
      </FloatingLabel>
        </Col>
        </Row>
        <Container fluid className='bisle'>
        <Row>
        <Col md={12}>
      <Button variant="primary" type="submit">Submit</Button>
      </Col>
      </Row>
      </Container>
      </div>
      </Form>
      </Col>
      <Col md={6}>
      <div className='OurOffice'>
        <div className='intel'>
        <FaMapMarkerAlt className='coupons'/>
      <h5>Our Office</h5>
      <p>123 Street, New York, USA</p>
      </div>
      <div className='intel'>
        <HiOutlineMailOpen className='coupons'/>
      <h5>Email Us</h5>
      <p>info@example.com</p>
      </div>
      <div className='intel'>
        <BsFillPhoneVibrateFill className='coupons'/>
      <h5>Email Us</h5>
      <p>info@example.com</p>
      </div>
      
      </div>
      </Col>
      </Row>      
  </Container>
    
  );
}

export default BasicExample;