import React from 'react';
import './ProjectPages.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import team from '../img/team-1.jpg';
import teams from '../img/team-2.jpg';
import teamss from '../img/team-3.jpg';

import testimonial1 from '../img/testimonial1.jpg';
import testimonial2 from '../img/testimonial2.jpg';
import testimonial3 from '../img/testimonial3.jpg';
import testimonial4 from '../img/testimonial4.jpg';

import blog1 from '../img/blog1.jpg';
import blog2 from '../img/blog2.jpg';

import { BsTwitter , BsFacebook,BsInstagram,BsLinkedin} from "react-icons/bs";

const ProjectPages = () => {
  return (
    <>
      <Container>
        <Row>
            <Col>
            <div className='swarna'>
      <p>PRICING PLAN</p>
      <h1>Pricing Plan For CCTV <br/>Security Services</h1>
      </div>
            </Col>
        </Row>
        <Row>
            <Col>
            <div className='baiscplan'>
            <div className='BasicBackground'>
            <h4>Basic Plan</h4> 
            <div className='department'>
            <span className='html-1'>$</span><h1 className='heading'>49</h1><span className='html'>/Mo</span> 
            </div>
            </div>
            <div className='underlines'>
            <p>HTML5 & CSS3</p>
            </div>
            <div className='failed'>
            <p className='underlines-1'>Bootstrap v5</p>
            </div>
            <div className='failed-1'>
            <p className='underlines-2'>Responsive Layout</p>
            </div>
            <div className='failed-2'>
            <p className='underlines-3'>Browsers Compatibility</p>
            </div>
            <div className='failed-3'>
            <p className='underlines-4'>Easy to Use</p>
            </div>
            <div className='button-1'>
            <Button variant = "primary">Order Now</Button>{' '}
            </div>
            </div>
            </Col>

            <Col>
            <div className='baiscplan-1'>
            <div className='BasicBackground-1 bg-danger'>
            <h4>Basic Plan</h4> 
            <div className='department-1'>
            <span className='html-2'>$</span><h1 className='heading-1'>49</h1><span className='html-2'>/Mo</span> 
            </div>
            </div>
            <div className='underlines-12'>
            <p>HTML5 & CSS3</p>
            </div>
            <div className='failed-23'>
            <p className='underlines-1'>Bootstrap v5</p>
            </div>
            <div className='failed-24'>
            <p className='underlines-2'>Responsive Layout</p>
            </div>
            <div className='failed-25'>
            <p className='underlines-4'>Browsers Compatibility</p>
            </div>
            <div className='failed-26'>
            <p className='underlines-5'>Easy to Use</p>
            </div>
            <div className='button-2'>
            <Button variant = "primary">Order Now</Button>{' '}
            </div>
            </div>
            </Col>
            <Col>
            <div className='baiscplan'>
            <div className='BasicBackground'>
            <h4>Basic Plan</h4> 
            <div className='department'>
            <span className='html-1'>$</span><h1 className='heading'>49</h1><span className='html-1'>/Mo</span> 
            </div>
            </div>
            <div className='underlines'>
            <p>HTML5 & CSS3</p>
            </div>
            <div className='failed'>
            <p className='underlines-1'>Bootstrap v5</p>
            </div>
            <div className='failed-1'>
            <p className='underlines-2'>Responsive Layout</p>
            </div>
            <div className='failed-2'>
            <p className='underlines-3'>Browsers Compatibility</p>
            </div>
            <div className='failed-3'>
            <p className='underlines-4'>Easy to Use</p>
            </div>
            <div className='button-1'>
            <Button variant = "primary">Order Now</Button>{' '}
            </div>
            </div>
            
            </Col>
            </Row>
            </Container>

            <Container fluid>
            <Row>
            <Col>
            <div className='specialoffer'>
            <h6>SPECIAL OFFER</h6>
            <h1>Save 50% On All Items<br/> Your First Order</h1>
            <p>Eirmod sed tempor lorem ut dolores sit kasd ipsum. Dolor ea et dolore et at sea ea at dolor justo ipsum duo rebum sea. Eos vero eos vero ea et dolore eirmod et. Dolores diam duo lorem. Elitr ut dolores magna sit. Sea dolore sed et.</p>
            
            <a href='#' className='buttonsside'>Order Now</a>
            <a href='#'className='buttonsside-1'>Read More</a>
            </div>
            </Col>  
            </Row>            
            </Container>

      <Container>
              <div className='teammembers'>
                <h5>team members</h5>
                <h1>Our Professional Team <br/>Members</h1>
                
              </div>
              <Row>
              <Col>
              <div className='fullname'>
              <img src={team}/>
              <ul className='iconstar'>
              <li><a href='#'><BsTwitter linksforimage/></a></li>
                <li><a href='#'><BsFacebook linksforimage/></a></li>
                <li><a href='#'><BsLinkedin linksforimage/></a></li>
                <li><a href='#'><BsInstagram linksforimage/></a></li>
                </ul> 
              </div>
              </Col>
              <Col>
              <div className='fullname'>
              <img src={teams}/>                
              <ul className='iconstar'>
                <li><a href='#'><BsTwitter linksforimage/></a></li>
                <li><a href='#'><BsFacebook linksforimage/></a></li>
                <li><a href='#'><BsLinkedin linksforimage/></a></li>
                <li><a href='#'><BsInstagram linksforimage/></a></li>
                </ul>
              </div>
              </Col>
              <Col>
              <div className='fullname'>
              <img src={teamss}/>                
              <ul className='iconstar'>
              <li><a href='#'><BsTwitter linksforimage/></a></li>
                <li><a href='#'><BsFacebook linksforimage/></a></li>
                <li><a href='#'><BsLinkedin linksforimage/></a></li>
                <li><a href='#'><BsInstagram linksforimage/></a></li>
                </ul> 
              </div>
              </Col>
            </Row>
            </Container>

            <Container>
            <Row>
              <Col>
              <div className='names'>
                <div className='headings'>
              <h4>Full Name</h4>
              <p>Designation</p>
              </div>
              </div>
              </Col>
              <Col>
              <div className='names'>
              <div className='headings'>
              <h4>Full Name</h4>
              <p>Designation</p>
              </div>
              </div>
              </Col>
              <Col>
              <div className='names'>
              <div className='headings'>
              <h4>Full Name</h4>
              <p>Designation</p>
              </div>
              </div>
              </Col>
            </Row>
            </Container>

            <Container>
            <Row>
            <div className='teammembers'>
                <h5>TESTIMONIAL</h5>
                <h1>What People Say About <br/>Our Services</h1>
              </div>
              <Col>
              <div className='owl-carosel testmonial-carousel'>
                <img src={testimonial1 }/>
                <div class="testimonial-text bg-light rounded p-4 mt-n5">
                        <p class="mt-5">Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam
                        </p>
                        <h4 class="text-truncate">Client Name</h4>
                        <i>Profession</i>
                    </div>
                </div>            

              </Col>
              <Col>
              
              <div className='owl-carosel testmonial-carousel'>
                <img src={testimonial2}/><div class="testimonial-text bg-light rounded p-4 mt-n5">
                        <p class="mt-5">Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam
                        </p>
                        <h4 class="text-truncate">Client Name</h4>
                        <i>Profession</i>
                    </div>
                </div>            
              
              </Col>
              <Col>
              <div className='owl-carosel testmonial-carousel'>
                <img src={testimonial3}/>
                <div class="testimonial-text bg-light rounded p-4 mt-n5">
                        <p class="mt-5">Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam
                        </p>
                        <h4 class="text-truncate">Client Name</h4>
                        <i>Profession</i>
                    </div>
                </div>            

              </Col>
              <Col>
              <div className='owl-carosel testmonial-carousel'>
                <img src={testimonial4}/>
                <div class="testimonial-text bg-light rounded p-4 mt-n5">
                        <p class="mt-5">Dolor et eos labore, stet justo sed est sed. Diam sed sed dolor stet amet eirmod eos labore diam
                        </p>
                        <h4 class="text-truncate">Client Name</h4>
                        <i>Profession</i>
                    </div>
                </div>            
              

              </Col>
            </Row>  
            </Container>

            <Container fluid>
            
            <div className='teammembers'>
                <h5>BLOG POST</h5>
                <h1>Latest Articles From Our <br/>Blog Post</h1>
              </div>
              <Row className='amazon1'>
              <Col> 
              <img src={blog1}/>
              <div className='amazon'>
              <p>ADMIN | WEB DESIGN</p>
              <h4>Kasd dolor lorem sit justo rebum <br/>stet justo elitr dolor amet s</h4>
              </div>
              </Col>
              <Col>  
              <img src={blog2}/>
              <div className='amazon'>
                <p>ADMIN | WEB DESIGN</p>
                <h4>Kasd dolor lorem sit justo rebum <br/>stet justo elitr dolor amet s</h4>
                
              </div>
              </Col>
              </Row>
              </Container>
    </>
  )
};
export default ProjectPages;
































